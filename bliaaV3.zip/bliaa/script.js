let offset = 0;
const sliderLine = document.querySelector('.slider-line');

document.querySelector('.slider-next').addEventListener('click', function(){
    offset = offset + 304;
    if (offset > 912) {
        offset = 0;
    }
    sliderLine.style.left = -offset + 'px';
});

document.querySelector('.slider-prev').addEventListener('click', function () {
    offset = offset - 304;
    if (offset < 0) {
        offset = 912;
    }
    sliderLine.style.left = -offset + 'px';
});

let offset1 = 0;
const sliderLine1 = document.querySelector('.slider-line1');

document.querySelector('.slider-next').addEventListener('click', function(){
    offset = offset + 304;
    if (offset > 912) {
        offset = 0;
    }
    sliderLine1.style.left = -offset + 'px';
});

document.querySelector('.slider-prev').addEventListener('click', function () {
    offset = offset - 304;
    if (offset < 0) {
        offset = 912;
    }
    sliderLine1.style.left = -offset + 'px';
});


let offset2 = 0;
const sliderLine2 = document.querySelector('.slider-line2');

document.querySelector('.slider-next').addEventListener('click', function(){
    offset = offset + 304;
    if (offset > 912) {
        offset = 0;
    }
    sliderLine2.style.left = -offset + 'px';
});

document.querySelector('.slider-prev').addEventListener('click', function () {
    offset = offset - 304;
    if (offset < 0) {
        offset = 912;
    }
    sliderLine2.style.left = -offset + 'px';
});








//BMW
let offset3 = 0;
const sliderLine3 = document.querySelector('.slider-line3');

document.querySelector('.slider-next3').addEventListener('click', function(){
    offset = offset + 636;
    if (offset > 1908) {
        offset = 0;
    }
    sliderLine3.style.left = -offset + 'px';
});

document.querySelector('.slider-prev3').addEventListener('click', function () {
    offset = offset - 636;
    if (offset < 0) {
        offset = 1908;
    }
    sliderLine3.style.left = -offset + 'px';
});

let offset4 = 0;
const sliderLine4 = document.querySelector('.slider-line4');

document.querySelector('.slider-next4').addEventListener('click', function(){
    offset = offset + 636;
    if (offset > 1908) {
        offset = 0;
    }
    sliderLine4.style.left = -offset + 'px';
});

document.querySelector('.slider-prev4').addEventListener('click', function () {
    offset = offset - 636;
    if (offset < 0) {
        offset = 1908;
    }
    sliderLine4.style.left = -offset + 'px';
});


